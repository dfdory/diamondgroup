<?php
// inclusion du fichier permettant le changement de langue
	include('../script_lang.php');
?>
<!DOCTYPE html>
<html lang="en-US"><head>
<?php include('../meta.php');?>
<style type="text/css">

</style>
    
    <script type="text/javascript" src="../jquery/jquery.js" ></script>
    <script src="../jquery/cufon-yui.js" type="text/javascript"></script>
    <script src="../jquery/jquery.cycle.all.js" type="text/javascript"></script>
    <script>
		
		$('#banners')
			.cycle({ 
				fx: 'fade', 
				delay: 2000 ,
				timeout: 5000,
				manualTrump:false,
				cleartypeNoBg: true,
				next: '#next',
				prev: '#prev'
			});
				

		$('#banner')
			.cycle({ 
				fx: 'fade', 
				delay: 2000 ,
				timeout: 5000,
				manualTrump:false,
				cleartypeNoBg: true,
				next: '#next',
				prev: '#prev'
			});
		$('#banner0')
			.cycle({ 
				fx: 'fade', 
				delay: 2000 ,
				timeout: 5000,
				manualTrump:false,
				cleartypeNoBg: true,
				next: '#next',
				prev: '#prev'
			});
	</script> 

 <style type="text/css">
	
</style>   
</head>

<body data-spy="scroll" data-offset="0" data-target="#theMenu" style="background-color: #e6e6e6;">
<?php include('header.php');?> 

<section>

<div class="col-md-12 col-md-offset-0 " id="msg" >
<div class="col-md-10 col-md-offset-1 "  >
			  		<div class="col-md-6 col-md-offset-3 text-center visible-md visible-lg visible-sm">
						<span class="txt-msg" style="line-height:50px"> <i class="fa fa-quote-left "></i>  LEADERSHIP driven by vision  <i class="fa fa-quote-right "></i></span> 
					</div>		
					<div class="col-sm-10 col-sm-offset-1 text-center visible-xs ">
						<span class="txt-msg" style="line-height:-50px;font-size:80%"> <i class="fa fa-quote-left "></i>  LEADERSHIP driven by vision  <i class="fa fa-quote-right "></i></span> 
					</div>	
</div>	
</div>

</section>
<section style="min-height:480px">
      <div class="container">
             <div class="row">
		  <div class="col-md-12 col-md-offset-0" >
		
			<div class="col-md-4 visible-md visible-lg lead0" id="lead0" style="margin-right: 4.1666665%;">
				<div id="about-msg">
					<div class="text-center banners" id="banners" >
						
                                		 <div class="text-center"  style="margin-top:25%">
                                    			<strong class="cap-txt text-center" style="">Different  Mindset</strong>
							<strong class="cap-txt text-center">Different  Methods </strong> 
                                    			<span class="low-txt text-center" style="">Equate to different results <span class="low-txt" style="color:#fff;opacity:0;filter: alpha(opacity=0);">Bigger isn't always better.You deserve a personalized approach & we deliver.</span> </span> 
                                		</div>
                                		<div class="text-center"  style="margin-top:25%">
                                    			<strong class="cap-txt">Attention Starved?</strong>
                                                         <span class="low-txt" style="font-size:98%;">Bigger isn't always better.<span class="low-txt" style="color:#fff;opacity:0;filter: alpha(opacity=0);">You deserve a personalized approach & we deliver.</span></span>
                                    			<span class="low-txt" style="font-size:98%;margin-top:-15px">You deserve a personalized approach & we deliver.</span>
                                		</div>
                                		<div class="text-center"  style="margin-top:25%">
                                    			<strong class="cap-txt">The Status Quo?</strong>
												<span class="low-txt">We see it...everywhere.We just don't believe in it.<span class="low-txt" style="color:#fff;opacity:0;filter: alpha(opacity=0);">The 'safe' choice rarely yields the best results.</span></span>
                                    			<span class="low-txt" style="font-size:98%;margin-top:-15px">The 'safe' choice rarely yields the best results.</span>
							
                                		</div>
                           			
                            	        </div>

                  
                           </div>

                    </div>
<div class="col-sm-6 col-sm-offset-3 visible-sm lead0" style="margin-top:10px">
				<div id="about-msg" >
					<div class="text-center" id="banner" >
                                	       <div class="text-center"  style="margin-top:25%">
                                    			<strong class="cap-txt text-center" style="">Different  Mindset</strong>
							<strong class="cap-txt text-center">Different  Methods </strong> 
                                    			<span class="low-txt text-center" style="">Equate to different results <span class="low-txt" style="color:#fff;opacity:0;filter: alpha(opacity=0);">Bigger isn't always better.You deserve a personalized approach & we deliver.</span> </span> 
                                		</div>
                                		<div class="text-center"  style="margin-top:25%">
                                    			<strong class="cap-txt">Attention Starved?</strong>
                                    			<span class="low-txt">Bigger isn't always better.You deserve a personalized approach & we deliver.</span>
                                		</div>
                                		<div class="text-center"  style="margin-top:25%">
                                    			<strong class="cap-txt">The Status Quo?</strong>
                                    			<!--<span class="low">We see it...everywhere.We just don't believe in it.The 'safe' choice rarely yields the best results.</span>-->
												<span class="low-txt">We see it...everywhere.We just don't believe in it. The 'safe' choice rarely yields the best results.<!--<span class="low-txt" style="color:#fff;opacity:0;filter: alpha(opacity=0);">The 'safe' choice rarely yields the best results.</span>--></span>
                                    			<!--<span class="low-txt" style="font-size:98%;margin-top:-15px">The 'safe' choice rarely yields the best results.</span>-->
                                		</div>
                           			
                            	        </div>

                  
                           </div>

                    </div>
<div class="col-xs-12 col-xs-offset-0 visible-xs lead0 visible-ox text-center" style="margin-top:10px;max-width:360px;">
				<div id="about-msg" class="ox" style="" >
					<div class="text-center" id="banner0" >
                                		 <div class="text-center lt" style="margin-top:110px;" >
                                    			<strong class="cap-txt text-center" style="font-size:120%">Different  Mindset</strong>
							<strong class="cap-txt text-center" style="font-size:120%">Different  Methods </strong> 
                                    			<span class="low-txt text-center" style="font-size:95%">Equate to different results <span class="low-txt" style="color:#fff;opacity:0;filter: alpha(opacity=0);">Bigger isn't always better.You deserve a personalized approach & we deliver.</span> </span> 
                                		</div>
                                		<div class="text-center lt "  style="margin-top:110px;" >
                                    			<strong class="cap-txt text-center" style="font-size:120%">Attention Starved?</strong>
                                    			<span class="low-txt text-center" style="font-size:95%;">Bigger isn't always better.You deserve a personalized approach & we deliver.</span>
                                		</div>
                                		<div class="text-center lt" style="margin-top:110px;">
                                    			<strong class="cap-txt text-center" style="font-size:120%">The Status Quo?</strong>
                                    			<!--<span class="low-txt text-center" style="font-size:95%;padding-left:10px">We see it...everywhere.We just don't believe in it.The 'safe' choice rarely yields the best results.</span>--><span class="low-txttext-center" style="font-size:95%;padding-left:10px">We see it...everywhere.We just don't believe in it. The 'safe' choice rarely yields the best results.</span>
                                		</div>
                           			
                            	        </div>

                  
                           </div>

                    </div>


<div class="col-md-7 col-sm-12  visible-lg visible-md visible-sm" id="lead">
                        <!--h4 class="section-titlex" style="margin-top:0px">Our LEADERSHIP define us</h4-->
			  
                       <div class="col-md-12 col-sm-offset-0" id="content">
				<div class="inner">
					<div class="kwiks_wrap">
						<ul class="kwicks vertical">

                       </strong>
							<li id="page_1" style="margin-top:20px">
								<div class="text"></div>
								<div class="cont text-justify">
									<p class="pad_top1" style="font-size:95%;margin-top:10px;padding-right:20px">
										 
									You know what they say about great leaders: they're ambitious, tenacious, and they don't take no for an answer. So when our founders dreamed of creating a real estate company, it was no doubt that best-in-class was going to be the standard. - Well, there was no standing in their way.                
									</p>
									
									<strong class="instig text-center" style="margin-top:25px" >Meet the company leaders <i class="fa fa-hand-o-right fa-2x" style="color: #3f4c6b;margin-left:5px"> </i> </strong>
								</div>
								
							</li>
							<li id="page_2">
								<div class="text text-justify"></div>
								<div class="cont">
<p class="pad_top1">
 <h6 class="section-lex" style="margin-top:0px"> <strong> Roselyne MPOUDI NGOLE </strong></h6>
<ul class="" style="margin-left:-5%;font-size:90%;padding-right:1%">
<li>Managing Director - SCI Diamond Group</li>
<li>e-banking Manager with Major International Bank </li>
<li>Industrial Engineer -  University of Moncton, New Brunswick, Canada </li>
<li>Eight (8) years experience in project management, process design & optimization, operations and electronic banking with Tier-1 international banks</li>
</ul>
	
									</p>
									
									

									
								</div>
							</li>
							<li id="page_3">
								<div class="text"></div>
								<div class="cont text-justify">
									<p class="pad_top1">
 <h6 class="section-lex" style="margin-top:0px"> <strong> Georges MPOUDI NGOLE </strong></h6>
<ul class="" style="margin-left:-5%;font-size:90%;padding-right:1%">
<li>Chairman - SCI Diamond Group</li>
<li>Chief Information Officer (CIO) with Leading International Telecommunications Company</a></li>
<li>Computer Engineer, alumni of MIT (Massachusetts Institute of Technology) USA, Gordon Institute of Business Science (GIBS) South Africa, Polytechnic School of Montreal and Montreal University, Canada </li>
<li>Thirteen (13) years experience in world class IT and Telecom services design, project management and operations</li>
</ul>
	
									</p>
									
									
								</div>
							</li>
							
							
						</ul>
					</div>
				</div>

			</div>
			
		</div>

 	</div>
</div>	
 



                      
</div>
   <div class="col-xs-12 col-xs-offset-0 visible-xs">
		<div class="col-xs-12" style="margin-top:30px">
 <img src="../img/team/leit.png" height="200" width="50" id="leadership" alt="Leadership" class="img-responsivex alignleft imageborder size-full img-responsivex leitx">

                       
                        <p class="no-img text-justify" style="font-size:11px;color:#000405;padding-top:20px">	 
									You know what they say about great leaders: they're ambitious, tenacious, and they don't take no for an answer. So when our founders dreamed of creating a real estate company, it was no doubt that best-in-class was going to be the standard. - Well, there was no standing in their way. 
			</p>
 
                       
		</div>
       
			 <strong class="instig text-center" style="margin-top:25px" >Meet the company leaders  </strong>
		<div class="col-xs-12">
 
                        <h6 class="section-lex" style="margin-top:30px"> <strong> Roselyne MPOUDI NGOLE </strong></h6>	

			  <img src="../img/team/man_dir.png" height="200" width="50" id="managing" alt="Managing Director" class="img-responsivex alignleft imageborder size-full img-responsivex leitx">
			
                        <p class="no-img text-justify" style="font-size:9px;color:#000405;padding-top:1px">	 
									<ul class="" style="font-size:88%;padding-right:.5px;list-style-type: none">

<li>- Managing Director - SCI Diamond Group</li>
<li>- e-banking Manager with Major International Bank </li>
<li>- Industrial Engineer - University of Moncton,New Brunswick,Canada</li>
<li class="no-img text-justify" style="font-size:11px;color:#000405;padding-top:-1px">- Eight (8) years experience in project management,process design & optimization,operations and electronic banking with Tier-1 international banks</li>

</ul> 


			</p>
 
                       
		</div>
		<div class="col-xs-12">
 
                        <h6 class="section-lex" style="margin-top:30px"> <strong>  Georges MPOUDI NGOLE </strong></h6>	

			  <img src="../img/team/chair.png" height="200" width="50" id="chairman" alt="Chairman" class="img-responsivex alignleft imageborder size-full img-responsivex leitx ">
			
                        <p class="no-img text-justify" style="font-size:9.5px;color:#000405;padding-top:1px">	 
									<ul class="" style="font-size:80%;padding-right:.5px;list-style-type: none">

<li>- Chairman - SCI Diamond Group</li>
<li>- Chief Information Officer (CIO) with Leading International Telecommunications Company</a></li>
<li>- Computer Engineer,alumni of MIT  USA,GIBS South Africa,Polytechnic School of Montreal and Montreal University,Canada</li>
<li class="no-img text-justify" style="font-size:11px;color:#000405;padding-top:-1px">- Thirteen (13) years experience in world class IT and Telecom services design,project management and operations</li>

</ul> 
			</p>
 
                       
		</div>

      
 		   </div>
	     </div>	          
       </div>
 

</section>  

<section>
      <div class="container">
             <div class="row">
<div class="col-md-4 col-sm-offset-1">
                      
</div>
		


</div>	          
       </div>
 

</section>  

<div class="container">
</div>
   
<?php include('footer.php');?>


 <!-- Scripts -->


    <script type="text/javascript" src="../jquery/kwicks-1.5.1.pack.js"></script>
    <script type="text/javascript" src="../jquery/script.js"></script>
    <script src="../bootstrap/js/bootstrap.js"></script>
    <script src="../jquery/app-plugin.js"></script>
    <script src="../jquery/smoothscroll.js"></script>
    <script src="../jquery/main.js"></script>
    
</body>
</html>
